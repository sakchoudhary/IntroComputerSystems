#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <string>
#include <cstring>
#include <iostream>
using namespace std; 

class KernelSemaphore{
	int semid;
public:
	KernelSemaphore(){};
	KernelSemaphore (int val, key_t key)//pass in file name 
	{
		short int value = (short int) val;
		// key_t key = ftok (filename.c_str(), 100);
		semid = semget(key, 1, IPC_CREAT | IPC_EXCL | 0666);  // why IPC_CREAT, beyond the scope
		if (semid < 0){
			printf ("Cannot create semaphore : %s", strerror(errno));
			exit (-1);
		}
		// initialize the semaphore value to an initial value = value
		// initially it was 0 meaning LOCKED
		struct sembuf sb = {0,value,0};
		if (semop(semid, &sb, 1) == -1) {
			cout << "constructor" <<endl;
			exit(-1); /* error, check errno */
		} 
	}
	
	void P(){
		struct sembuf sb = {0, -1, 0};
		if (semop(semid, &sb, 1) == -1) {
			//cout << "p, semid : "<<semid <<endl;
			perror("semop");
			exit(1);
		}
	}
	
	void V(){
		struct sembuf sb = {0, 1, 0};
		if (semop(semid, &sb, 1) == -1) {
						cout << "v" <<endl;

			perror("semop");
			exit(1);
		}
	}
	
	~KernelSemaphore (){
		//union semun arg={0};
		if (semctl(semid, 0, IPC_RMID, 0) == -1) {
			perror("semctl");
			exit(1);
		}
	}
};
