/* 
    File: requestchannel.C

    Author: R. Bettati
            Department of Computer Science
            Texas A&M University
    Date  : 2012/07/11

*/

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include <cassert>
#include <cstring>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <errno.h>


#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#include "reqchannel.h"

#define SHM_SIZE 1024 
/*--------------------------------------------------------------------------*/
/* DATA STRUCTURES */ 
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* CONSTANTS */
/*--------------------------------------------------------------------------*/

const bool VERBOSE = true; // 

/*--------------------------------------------------------------------------*/
/* FORWARDS */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* PRIVATE METHODS FOR CLASS   R e q u e s t C h a n n e l  */
/*--------------------------------------------------------------------------*/

std::string RequestChannel::pipe_name(Mode _mode) {
	std::string pname = "fifo_" + my_name;

	if (my_side == CLIENT_SIDE) {
		if (_mode == READ_MODE)
			pname += "1";
		else
			pname += "2";
	}
	else {
	/* SERVER_SIDE */
		if (_mode == READ_MODE)
			pname += "2";
		else
			pname += "1";
	}

	return pname;
}

void RequestChannel::open_write_pipe(const char * _pipe_name) {

	if(write_pipe_opened) close(wfd);

	if(VERBOSE) std::cout << my_name << ":" << side_name << ": mkfifo write pipe" << std::endl;

	if (mkfifo(_pipe_name, 0600) < 0) {
		if (errno != EEXIST) {
			int prev_errno = errno;
			if(read_pipe_opened) close(rfd);
			remove(pipe_name(READ_MODE).c_str());
			remove(pipe_name(WRITE_MODE).c_str());
			errno = prev_errno;
			throw sync_lib_exception(my_name + ":" + side_name + ": error creating pipe for writing");
		}
	}

	if(VERBOSE) std::cout << my_name << ":" << side_name << ": open write pipe" << std::endl;

	wfd = open(_pipe_name, O_WRONLY);
	if (wfd < 0) {
		int prev_errno = errno;
		if(read_pipe_opened) close(rfd);
		remove(pipe_name(READ_MODE).c_str());
		remove(pipe_name(WRITE_MODE).c_str());
		errno = prev_errno;
		throw sync_lib_exception(my_name + ":" + side_name + ": error opening pipe for writing");
	}

	if(VERBOSE) std::cout << my_name << ":" << side_name << ": done opening write pipe" << std::endl;
	write_pipe_opened = true;
}

void RequestChannel::open_read_pipe(const char * _pipe_name) {

	if(read_pipe_opened) close(rfd);
	
	if(VERBOSE) std::cout << my_name << ":" << side_name << ": mkfifo read pipe" << std::endl;

	if (mkfifo(_pipe_name, 0600) < 0) {
		if (errno != EEXIST) {
			int prev_errno = errno;
			if(write_pipe_opened) close(wfd);
			remove(pipe_name(READ_MODE).c_str());
			remove(pipe_name(WRITE_MODE).c_str());
			errno = prev_errno;
			throw sync_lib_exception(my_name + ":" + side_name + ": error creating pipe for reading");
		}
	}

	if(VERBOSE) std::cout << my_name << ":" << side_name << ": open read pipe" << std::endl;

	rfd = open(_pipe_name, O_RDONLY);
	if (rfd < 0) {
		int prev_errno = errno;
		if(write_pipe_opened) close(wfd);
		remove(pipe_name(READ_MODE).c_str());
		remove(pipe_name(WRITE_MODE).c_str());
		errno = prev_errno;
		throw sync_lib_exception(my_name + ":" + side_name + ": error opening pipe for reading");
	}

	if(VERBOSE) std::cout << my_name << ":" << side_name << ": done opening read pipe" << std::endl;
	read_pipe_opened = true;
}

/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR/DESTRUCTOR FOR CLASS   R e q u e s t C h a n n e l  */
/*--------------------------------------------------------------------------*/

RequestChannel::RequestChannel(const std::string _name, const Side _side) :
my_name(_name), my_side(_side), side_name((_side == RequestChannel::SERVER_SIDE) ? "SERVER" : "CLIENT")
{

	string file1 = my_name + ".txt";

	ofstream outfile1;
	outfile1.open(file1.c_str(), std::ios_base::app);


	ck = ftok(file1.c_str(),1); //client key 
	sk = ftok(file1.c_str(),2); //server key 

//4 semaphore keys 
	sem1 = ftok(file1.c_str(),1); //client key 
	sem2 = ftok(file1.c_str(),2); //server key 
	sem3 = ftok(file1.c_str(),3); //client key 
	sem4 = ftok(file1.c_str(),4); //server key 

	cs_full = KernelSemaphore(0,sem1); 
	cs_empty = KernelSemaphore(1,sem2); 

	sc_full = KernelSemaphore(0,sem3); 
	sc_empty = KernelSemaphore(1,sem4); 
	

	clid = -1; srid = -1; 
	int perms = 0666; 
    if(my_side == SERVER_SIDE){
        perms |= IPC_CREAT;
    }
    while(clid < 0 || srid < 0){
    	cout << "creating "<<endl; 
        clid = shmget(ck,SHM_SIZE, perms);
        srid = shmget(sk, SHM_SIZE, perms);
        //cout << clid << " " << srid <<endl; 
    }
   
   	if(my_side == CLIENT_SIDE){
			data1 = (char*) shmat(clid,0,0);
			data2 = (char*) shmat(srid,0,0);
			cout << "**********" << data1 << data2 <<endl; 
	}
	else{
			data1 = (char*) shmat(srid,0,0);
			data2 = (char*) shmat(clid,0,0);
	}


	//attach memory segments

	outfile1.close(); 

}

RequestChannel::~RequestChannel() {

	// shmctl(data1); 
	// shmctl(data2);

}

/*--------------------------------------------------------------------------*/
/* READ/WRITE FROM/TO REQUEST CHANNELS  */
/*--------------------------------------------------------------------------*/

const int MAX_MESSAGE = 255;

std::string RequestChannel::send_request(std::string _request) {
	pthread_mutex_lock(&send_request_lock);
	if(cwrite(_request) < 0) {
		pthread_mutex_unlock(&send_request_lock);
		return "ERROR";
	}
	std::string s = cread();
	pthread_mutex_unlock(&send_request_lock);
	return s;
}

std::string RequestChannel::cread() {
	string d ; 

	if (my_side == CLIENT_SIDE){//client read
		sc_full.P();
		std::string s(data2);
		sc_empty.V();
 
	}
	else{ //server reading
		cs_full.P();
		std::string d(data1); 
		cs_empty.V();
	}
	return d; 

}

int RequestChannel::cwrite(std::string _msg) {

	if (my_side == CLIENT_SIDE){//client write
		cs_empty.P();
		strncpy(data1, _msg.c_str(),SHM_SIZE);
		cs_full.V();
 
	}
	else{ //server write 
		sc_empty.P();
		strncpy(data2, _msg.c_str(),SHM_SIZE);
		sc_full.V();
	}
	return 0; 
}

/*--------------------------------------------------------------------------*/
/* ACCESS THE NAME OF REQUEST CHANNEL  */
/*--------------------------------------------------------------------------*/

std::string RequestChannel::name() {
	return my_name;
}

/*--------------------------------------------------------------------------*/
/* ACCESS FILE DESCRIPTORS OF REQUEST CHANNEL  */
/*--------------------------------------------------------------------------*/

int RequestChannel::read_fd() {
	return rfd;
}

int RequestChannel::write_fd() {
	return wfd;
}





